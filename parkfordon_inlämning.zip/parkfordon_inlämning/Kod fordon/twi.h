/*
 * twi.h
 *
 * Created: 2014-05-09 12:43:08
 *  Author: johe0179
 */ 


#ifndef TWI_H_
#define TWI_H_

uint16_t compass_update();

#endif /* TWI_H_ */